package org.lab04;

public class StartApp {
    public static void main(String[] args) {
        new MainPanel();
    }
}
